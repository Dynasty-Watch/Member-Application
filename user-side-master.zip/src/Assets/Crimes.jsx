export const Crimes = [
    {
        id : 1,
        Type : "Assault"
    },
    {
        id : 2,
        Type : "Robbery"
    },{
        id : 3,
        Type : "Armed Robbery"
    },
    {
        id : 4,
        Type : "Hijacking"
    },{
        id : 5,
        Type : "Organized Crime"
    },{
        id : 6,
        Type : "Shoplifting"
    },{
        id : 7,
        Type : "Sexual Offence"
    },{
        id : 8,
        Type : "Kidnapping"
    }
]
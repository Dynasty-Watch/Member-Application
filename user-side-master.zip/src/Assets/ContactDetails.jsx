export const ContactDetails = [
    {
        id: 1,
        service: "Police",
        image: "",
        href: "10111",
    },
    {
        id: 2,
        service: "Ambulance",
        image: "",
        href: "10177",
    },
    {
        id: 3,
        service: "Disaster Management ",
        image: "",
        href: "012 848 4602",
    },
    {
        id: 4,
        service: "Poison Emergency Management ",
        image: "",
        href: " 021 689 5227",
    },
    // {
    //     id: 5,
    //     service: "Mental Health Line",
    //     image: "",
    //     href: "011 234 4837",
    // },
    {
        id: 5,
        service: "Gender based Violance",
        image: "",
        href: "0800 428 428",
    }
]